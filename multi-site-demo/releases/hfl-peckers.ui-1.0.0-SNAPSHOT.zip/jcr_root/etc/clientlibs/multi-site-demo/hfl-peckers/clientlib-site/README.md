This client library should contain general styles (and possibly scripts) specific to the HFL Peckers site. JS/CSS/LESS
files specific to components and generic to all sites should be stored in client library folders within the respective
components.
