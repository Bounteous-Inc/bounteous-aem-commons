This clientlib simply enables the Shared Component Properties feature from ACS AEM Commons in the Touch UI authoring
editor (editor.html).