This is a base client library of only super-generic items that are good to share in all HFL site clientlibs.

Nothing that is component-specific OR site-specific should go inside this client library.