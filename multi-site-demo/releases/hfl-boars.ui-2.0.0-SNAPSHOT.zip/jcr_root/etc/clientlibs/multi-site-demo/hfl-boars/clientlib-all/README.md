This client library should be left empty - it's purpose is to join all client libraries that the site requires.
This allows us to manage what clientlibs are included and in what order, as well accelerates the site by concatenating
everything into one JS file and one CSS file.
