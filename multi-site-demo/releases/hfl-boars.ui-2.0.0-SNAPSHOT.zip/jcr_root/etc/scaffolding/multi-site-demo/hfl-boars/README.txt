Scaffolding should be converted to Structured Content Fragments per current AEM practices.

For this reason it is not tested to work correctly on AEM 6.3.